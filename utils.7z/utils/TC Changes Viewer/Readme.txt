TC Changes Viewer 2.01
======================

"TC Changes Viewer" displays the contents of the Total Commander history file but in a convenient way.

-----------------
Versions history
-----------------
Version 2.01 --- 25 November, 2011
    Fixed: The changes list always empty if "History.txt" file not exists in Total Commander folder.

Version 2.00 --- 24 November, 2011
    Added: Search function.
    Added: New hotkeys Ctrl+C and Ctrl+Ins to copy the the selected line to the clipboard.
    Added: Accept opening file via command line.
    Added: New color option for additions.
    Added: New color option for fixes.
    Added: New option to show/hide icons.
    Added: Change the program icon.
    Added: Better parsing for full TC history file.
    Added: Show date in separate columns (optionally).
    Added: When "All" version selected, highlight the version of the selected change.
    Added: New toolbar button to show the changes list in reverse order.
    Added: New command File> Statistics.
    Fixed: Long date in status bar was wrong for some locales.
    Fixed: The program hangs on start if "History.txt" file not exists in Total Commander folder.

Version 1.00 --- 20 October, 2011
    * First release.
