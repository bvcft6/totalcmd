TC PlugMan es un manejador externo de plugins para Total Commander.
Le permite:

 - Ver la lista de todos los plugins Lister/FS/Compresor/Contenido instalados
 - Agregar/remover/configurar plugins (�m�s f�cil que en TC!)
 - Activar/desactivar plugins (�TC no puede hacer esto!)
 - Ejecutar/reiniciar TC

Notas
- Tambi�n le muestra si TC esta actualmente en ejecuci�n; si es as�, luego de
  hacer algunos cambios, debe reiniciar TC para que los cambios tengan efecto.
- La caracter�stica "Instalar desde archivo" solo opera con WinRAR instalado
  (http://rarlab.com).

Comprobado y funciona en Total Commander V5.5/6.0, p.e. en la versi�n actual 6.54.
Freeware/Open-Source.


Copyright (c) 2004-2007 Alexey Torgashin <atorg@yandex.ru>
http://atorg.net.ru
http://totalcmd.net/plugring/tc_plugman.html
